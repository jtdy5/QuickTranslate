import SwiftUI
import PhotosUI
import Vision
import Translation

struct OCRBlock: Identifiable {
    let id = UUID()
    let text: String
    /// Vision normalized coordinates: origin at lower-left.
    let box: CGRect
}

struct ContentView: View {
        @State private var photoItem: PhotosPickerItem?
    @State private var sourceImage: UIImage?
    @State private var blocks: [OCRBlock] = []
    @State private var translations: [UUID: String] = [:]
    @State private var targetCode = "en"
    @State private var configuration: TranslationSession.Configuration?
    @State private var isRecognizing = false
    @State private var errorMessage: String?

    private let languages: [(name: String, code: String)] = [
        ("English", "en"), ("Danish", "da"), ("Spanish", "es"),
        ("French", "fr"), ("German", "de"), ("Japanese", "ja"),
        ("Korean", "ko"), ("Chinese (Simplified)", "zh-Hans"),
        ("Italian", "it"), ("Portuguese", "pt")
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("QuickTranslate")
                            .font(.largeTitle.bold())
                        Text("Open a screenshot and translate its text")
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "character.bubble")
                        .font(.system(size: 30, weight: .medium))
                        .foregroundStyle(.tint)
                }

                HStack {
                    Text("Translate to")
                        .foregroundStyle(.secondary)
                    Spacer()
                    Picker("Translate to", selection: $targetCode) {
                        ForEach(languages, id: \.code) { language in
                            Text(language.name).tag(language.code)
                        }
                    }
                    .labelsHidden()
                    .onChange(of: targetCode) { _, newValue in
                        startTranslation(target: newValue)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))

                PhotosPicker(selection: $photoItem, matching: .images) {
                    Label("Choose screenshot or photo", systemImage: "photo.on.rectangle.angled")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(.tint, in: RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                }
                .onChange(of: photoItem) { _, item in
                    Task { await loadImage(from: item) }
                }

                if isRecognizing {
                    ProgressView("Recognizing text…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let sourceImage {
                    translatedPreview(sourceImage)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color(uiColor: .secondarySystemBackground),
                                    in: RoundedRectangle(cornerRadius: 18))
                        .clipShape(RoundedRectangle(cornerRadius: 18))

                    HStack {
                        Label("\(blocks.count) text regions", systemImage: "text.viewfinder")
                        Spacer()
                        if !translations.isEmpty {
                            Text("Translated")
                                .foregroundStyle(.green)
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                } else {
                    ContentUnavailableView(
                        "Ready when you are",
                        systemImage: "viewfinder",
                        description: Text("Choose a screenshot or photo. QuickTranslate will detect the text and translate it in place.")
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }

                Text("Tip: assign “Open QuickTranslate” to a Shortcut or Action Button. Then choose the screenshot here.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                if let errorMessage {
                    Text(errorMessage)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .translationTask(configuration) { session in
                await translateAll(using: session)
            }
        }
    }

    @ViewBuilder
    private func translatedPreview(_ image: UIImage) -> some View {
        GeometryReader { proxy in
            let size = proxy.size
            let scale = min(size.width / image.size.width, size.height / image.size.height)
            let renderedWidth = image.size.width * scale
            let renderedHeight = image.size.height * scale

            ZStack {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: renderedWidth, height: renderedHeight)

                // The OCR boxes and the image use the exact same fitted
                // coordinate space, avoiding offsets from letterboxing.
                ForEach(blocks) { block in
                    if let translated = translations[block.id] {
                        Text(translated)
                            .font(.system(size: max(9, min(15, renderedWidth / thirty)), weight: .semibold))
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .minimumScaleFactor(0.55)
                            .padding(.horizontal, 3)
                            .padding(.vertical, 2)
                            .background(Color(uiColor: .systemBackground).opacity(0.96), in: RoundedRectangle(cornerRadius: 5))
                            .overlay(RoundedRectangle(cornerRadius: 5).stroke(.tint.opacity(0.7), lineWidth: 1))
                            .frame(
                                width: max(42, block.box.width * renderedWidth),
                                height: max(20, block.box.height * renderedHeight),
                                alignment: .center
                            )
                            .position(
                                x: (size.width - renderedWidth) / 2 + block.box.midX * renderedWidth,
                                y: (size.height - renderedHeight) / 2 + (1 - block.box.midY) * renderedHeight
                            )
                    }
                }
            }
            .frame(width: size.width, height: size.height)
        }
    }

    private func loadImage(from item: PhotosPickerItem?) async {
        guard let item else { return }
        do {
            guard let data = try await item.loadTransferable(type: Data.self),
                  let image = UIImage(data: data) else {
                errorMessage = "Couldn't load that image."
                return
            }
            await MainActor.run {
                sourceImage = image
                blocks = []
                translations = [:]
                errorMessage = nil
                isRecognizing = true
            }
            let found = try await recognizeText(in: image)
            await MainActor.run {
                blocks = found
                isRecognizing = false
                startTranslation(target: targetCode)
                if found.isEmpty {
                    errorMessage = "No readable text was found in this screenshot."
                }
            }
        } catch {
            await MainActor.run {
                isRecognizing = false
                errorMessage = error.localizedDescription
            }
        }
    }

    private func recognizeText(in image: UIImage) async throws -> [OCRBlock] {
        guard let cgImage = image.cgImage else { return [] }
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error {
                    continuation.resume(throwing: error)
                    return
                }
                let observations = (request.results as? [VNRecognizedTextObservation]) ?? []
                let result = observations.compactMap { observation -> OCRBlock? in
                    guard let candidate = observation.topCandidates(1).first else { return nil }
                    return OCRBlock(text: candidate.string, box: observation.boundingBox)
                }
                continuation.resume(returning: result)
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            try VNImageRequestHandler(cgImage: cgImage).perform([request])
        }
    }

    private func startTranslation(target: String) {
        guard !blocks.isEmpty else { return }
        translations = [:]
        configuration = TranslationSession.Configuration(
            source: nil,
            target: Locale.Language(identifier: target)
        )
    }

    private func translateAll(using session: TranslationSession) async {
        do {
            for block in blocks {
                let response = try await session.translate(block.text)
                await MainActor.run {
                    translations[block.id] = response.targetText
                }
            }
        } catch {
            await MainActor.run {
                errorMessage = "Translation failed: \(error.localizedDescription)"
            }
        }
    }
}

private extension Array where Element: Hashable {
    func uniqued() -> [Element] {
        var seen = Set<Element>()
        return filter { seen.insert($0).inserted }
    }
}

private let thirty: CGFloat = 30
