import AppIntents

/// A free-account-friendly App Shortcut that opens QuickTranslate.
/// The user then selects the screenshot using the system Photos picker.
struct OpenQuickTranslateIntent: AppIntent {
    static var title: LocalizedStringResource = "Open QuickTranslate"
    static var description = IntentDescription(
        "Open QuickTranslate so you can choose a screenshot and translate it."
    )
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult {
        .result(dialog: "QuickTranslate is ready. Choose a screenshot to translate.")
    }
}

struct QuickTranslateShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: OpenQuickTranslateIntent(),
            phrases: [
                "Open \(.applicationName)",
                "Start \(.applicationName)"
            ],
            shortTitle: "Quick Translate",
            systemImageName: "character.bubble"
        )
    }
}
